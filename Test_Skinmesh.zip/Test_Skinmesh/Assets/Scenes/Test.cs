﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour {

    void Start () {
        Matrix4x4 matrix = transform.worldToLocalMatrix;

        //网格数组
        MeshFilter[] meshFilters = this.GetComponentsInChildren<MeshFilter>();
        CombineInstance[] combineInstances = new CombineInstance[meshFilters.Length];
        for (int i = 0; i < meshFilters.Length; ++i)
        {
            combineInstances[i].mesh = meshFilters[i].sharedMesh;
            combineInstances[i].transform = meshFilters[i].transform.localToWorldMatrix * matrix;
        }

        //材质数组
        Material[] materials = new Material[meshFilters.Length];
        MeshRenderer[] meshRenders = this.GetComponentsInChildren<MeshRenderer>();
        for (int i = 0; i < meshRenders.Length; ++i)
        {
            materials[i] = meshRenders[i].sharedMaterial;
        }

        //新建网格容器
        Mesh newMesh = new Mesh();
        newMesh.name = "newMesh";
        //新网格赋值给当前mesh
        MeshFilter mf = this.GetComponent<MeshFilter>();
        mf.mesh = newMesh;
        //合并网格
        newMesh.CombineMeshes(combineInstances, false); //第二个参数的意思，如果为false，则表明有多个材质；如果是true，则表明一个材质。
        //如果是false的话，合并完的Mesh，那么就会有多个submesh，理应对应多个Material。
        //如果是true的话，那么合并完的mesh就只有一个submesh，理应对对应1个Material。
        //材质赋值
        MeshRenderer mr = this.GetComponent<MeshRenderer>();
        mr.sharedMaterials = materials;


        //这里针对多个skinmesh合并 发现当mesh包含多个submeshes时，合并成功后，无法渲染显示出来。
        //解决： ci.mesh.triangles = smr.sharedMesh.triangles  必须重新指定三角形

        //SkinnedMeshRenderer[] allSkineMeshList;
        //List<CombineInstance> combineInstances = new List<CombineInstance>();
        //foreach (SkinnedMeshRenderer smr in allSkineMeshList)
        //{
        //    for (int sub = 0; sub < smr.sharedMesh.subMeshCount; sub++)
        //    {
        //        CombineInstance ci = new CombineInstance();
        //        ci.mesh = smr.sharedMesh;
        //        ci.mesh.triangles = smr.sharedMesh.triangles; //这里重新    指定包含网格中所有三角形的数组。

        //        ci.subMeshIndex = sub;
        //        ci.transform = matrix * smr.transform.localToWorldMatrix;
        //        combineInstances.Add(ci);
        //    }
        //}

    }
}
